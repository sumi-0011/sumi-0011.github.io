### Hi there 👋

- 🔭 I’m currently working on ... 충남대
- 🌱 I’m currently learning ...   데이터 베이스, 데이터 통신 , react
<!--
**sumi-0011/sumi-0011** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ... 충남대
- 🌱 I’m currently learning ...   데이터 베이스, 데이터 통신 , 리액트 등
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
[![Anurag's GitHub stats](https://github-readme-stats.vercel.app/api?username=sumi-0011)](https://github.com/anuraghazra/github-readme-stats)

